package yjc.wdb.scts.DAO;

import yjc.wdb.scts.bean.Customer;

public interface CustomerDAO {

	public int checkCustomer(Customer customer) throws Exception;
	
}
