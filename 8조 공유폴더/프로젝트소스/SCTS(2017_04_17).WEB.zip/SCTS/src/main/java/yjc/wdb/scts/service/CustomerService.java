package yjc.wdb.scts.service;

import yjc.wdb.scts.bean.Customer;

public interface CustomerService {
	
	public int checkCustomer(Customer customer) throws Exception;

}
