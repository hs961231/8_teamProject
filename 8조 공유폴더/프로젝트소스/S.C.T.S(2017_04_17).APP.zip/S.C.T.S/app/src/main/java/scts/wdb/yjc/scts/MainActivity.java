package scts.wdb.yjc.scts;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static java.sql.DriverManager.println;

public class MainActivity extends AppCompatActivity {


    private EditText user_id_input;
    private EditText user_pw_input;
    private String user_id;
    private String user_pw;
    SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        NetworkTask2 networkTask = new NetworkTask2();
        networkTask.execute("");

        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                user_id_input = (EditText) findViewById(R.id.userId);
                user_id = user_id_input.getText().toString();
                user_pw_input = (EditText) findViewById(R.id.userPw);
                user_pw = user_pw_input.getText().toString();


                sp = getSharedPreferences("test", 0);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("customer_id", user_id);
                editor.commit();



                JSONObject  jsonObject = new JSONObject();
                try {
                    jsonObject.put("user_id", user_id);
                    jsonObject.put("user_pw", user_pw);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String json = jsonObject.toString();



                NetworkTask networkTask = new NetworkTask();
                networkTask.execute(json);


            }
        });

        findViewById(R.id.join).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Join.class);
                startActivity(intent);
            }
        });

    }

    private class NetworkTask extends AsyncTask<String, String, String>{

        protected  void onPreExcute(){

            super.onPreExecute();
        }




        @Override
        protected String doInBackground(String... json) {


            HttpClient.Builder http = new HttpClient.Builder("GET", "http://106.249.38.66:8080/scts/checkCustomer?customer_id="+user_id+"&customer_pw="+user_pw );
            http.addOrReplace("json", json[0]);

            // HTTP 요청 전송
            HttpClient post = http.create();

            post.request();



            // 응답 상태코드 가져오기
            int statusCode = post.getHttpStatusCode();

            // 응답 본문 가져오기
            String body = post.getBody();


            return body;
        }

        protected void onPostExecute(String s){

            Log.i("JSON/RESULT", s);

            if(s.equals("1")){

                String str = sp.getString("customer_id", "");
                if(str.equals(user_id)){
                    Intent intent = new Intent(getApplicationContext(), WebViewTest.class);
                    startActivity(intent);
                }else{
                    setContentView(R.layout.activity_main);
                }


            }else{
                Toast.makeText(getApplicationContext(), "로그인 실패!!!!", Toast.LENGTH_LONG).show();
            }

        }

    }

    private class NetworkTask2 extends AsyncTask<String, String, String>{

        protected  void onPreExcute(){

            super.onPreExecute();
        }




        @Override
        protected String doInBackground(String... json) {
            HttpClient.Builder http = new HttpClient.Builder("POST", "http://106.249.38.66:8080/scts/android2");

            // HTTP 요청 전송
            HttpClient post = http.create();

            post.request();



            // 응답 상태코드 가져오기
            int statusCode = post.getHttpStatusCode();

            // 응답 본문 가져오기
            String body = post.getBody();


            return body;
        }

        protected void onPostExecute(String s){

            Log.i("HI", s);




        }

    }
}