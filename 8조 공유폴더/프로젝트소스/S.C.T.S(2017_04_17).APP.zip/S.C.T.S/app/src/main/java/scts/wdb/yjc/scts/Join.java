package scts.wdb.yjc.scts;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Join extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);




    }
}
