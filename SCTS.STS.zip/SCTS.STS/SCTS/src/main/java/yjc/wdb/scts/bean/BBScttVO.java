package yjc.wdb.scts.bean;

public class BBScttVO {
	
	private int bbsctt_code;
	private String bbsctt_sj;
	private String bbsctt_cn;
	
	public int getBbsctt_code() {
		return bbsctt_code;
	}
	public void setBbsctt_code(int bbsctt_code) {
		this.bbsctt_code = bbsctt_code;
	}
	public String getBbsctt_sj() {
		return bbsctt_sj;
	}
	public void setBbsctt_sj(String bbsctt_sj) {
		this.bbsctt_sj = bbsctt_sj;
	}
	public String getBbsctt_cn() {
		return bbsctt_cn;
	}
	public void setBbsctt_cn(String bbsctt_cn) {
		this.bbsctt_cn = bbsctt_cn;
	}

}
