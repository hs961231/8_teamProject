package yjc.wdb.scts.bean;

public class DrawingVO {
	private int		drw_code;
	private String	drw_flpth;
	
	public int getDrw_code() {
		return drw_code;
	}
	public void setDrw_code(int drw_code) {
		this.drw_code = drw_code;
	}
	public String getDrw_flpth() {
		return drw_flpth;
	}
	public void setDrw_flpth(String drw_flpth) {
		this.drw_flpth = drw_flpth;
	}
	
}
