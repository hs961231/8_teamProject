package yjc.wdb.scts.bean;

public class Detail_categoryVO {
	private int		detailctgry_code;
	private int		lclasctgry_code;
	private String	detailctgry_nm;

	
	public int getDetailctgry_code() {
		return detailctgry_code;
	}
	public void setDetailctgry_code(int detailctgry_code) {
		this.detailctgry_code = detailctgry_code;
	}
	public int getLclasctgry_code() {
		return lclasctgry_code;
	}
	public void setLclasctgry_code(int lclasctgry_code) {
		this.lclasctgry_code = lclasctgry_code;
	}
	public String getDetailctgry_nm() {
		return detailctgry_nm;
	}
	public void setDetailctgry_nm(String detailctgry_nm) {
		this.detailctgry_nm = detailctgry_nm;
	}
	
}
