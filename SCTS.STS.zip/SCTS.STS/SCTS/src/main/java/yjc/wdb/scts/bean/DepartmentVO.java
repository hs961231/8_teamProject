package yjc.wdb.scts.bean;

public class DepartmentVO {
	private int		dept_code;
	private String	dept_nm;
	
	public int getDept_code() {
		return dept_code;
	}
	public void setDept_code(int dept_code) {
		this.dept_code = dept_code;
	}
	public String getDept_nm() {
		return dept_nm;
	}
	public void setDept_nm(String dept_nm) {
		this.dept_nm = dept_nm;
	}
	
}
