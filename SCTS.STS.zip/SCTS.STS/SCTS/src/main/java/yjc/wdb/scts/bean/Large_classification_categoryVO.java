package yjc.wdb.scts.bean;

public class Large_classification_categoryVO {
	private int		lclasctgry_code;
	private String	lclasctgry_nm;
	private String	lclasctgry_color;
	
	public int getLclasctgry_code() {
		return lclasctgry_code;
	}
	public void setLclasctgry_code(int lclasctgry_code) {
		this.lclasctgry_code = lclasctgry_code;
	}
	public String getLclasctgry_nm() {
		return lclasctgry_nm;
	}
	public void setLclasctgry_nm(String lclasctgry_nm) {
		this.lclasctgry_nm = lclasctgry_nm;
	}
	public String getLclasctgry_color() {
		return lclasctgry_color;
	}
	public void setLclasctgry_color(String lclasctgry_color) {
		this.lclasctgry_color = lclasctgry_color;
	}
}
