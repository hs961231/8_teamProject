package yjc.wdb.scts.service;

import java.util.HashMap;
import java.util.List;

public interface Branch_officeService {
	public List<HashMap<String, String>> selectBranchNameList() throws Exception;

}
