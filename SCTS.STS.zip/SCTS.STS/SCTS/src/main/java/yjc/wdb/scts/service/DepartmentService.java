package yjc.wdb.scts.service;

public interface DepartmentService {

}
