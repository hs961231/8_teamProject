package yjc.wdb.scts.dao;

public interface Large_classification_categoryDAO {

}
