package yjc.wdb.scts.service;

public interface Detail_categoryService {

}
