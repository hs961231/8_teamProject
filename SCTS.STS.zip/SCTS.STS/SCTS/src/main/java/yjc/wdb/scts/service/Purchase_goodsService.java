package yjc.wdb.scts.service;

import java.util.HashMap;

import yjc.wdb.scts.bean.Purchase_goodsVO;

public interface Purchase_goodsService {
	public void insertPurchase_goods(HashMap<String, String> vo) throws Exception;
}
