package yjc.wdb.scts.bean;

public class BeaconVO {
	private int		beacon_code;
	private int		beacon_mjr;
	private int		beacon_mnr;
	private String	beacon_sttus;
	private int		bhf_code;
	
	public int getBeacon_code() {
		return beacon_code;
	}
	public void setBeacon_code(int beacon_code) {
		this.beacon_code = beacon_code;
	}
	public int getBeacon_mjr() {
		return beacon_mjr;
	}
	public void setBeacon_mjr(int beacon_mjr) {
		this.beacon_mjr = beacon_mjr;
	}
	public int getBeacon_mnr() {
		return beacon_mnr;
	}
	public void setBeacon_mnr(int beacon_mnr) {
		this.beacon_mnr = beacon_mnr;
	}
	public String getBeacon_sttus() {
		return beacon_sttus;
	}
	public void setBeacon_sttus(String beacon_sttus) {
		this.beacon_sttus = beacon_sttus;
	}
	public int getBhf_code() {
		return bhf_code;
	}
	public void setBhf_code(int bhf_code) {
		this.bhf_code = bhf_code;
	}
	
}
