package yjc.wdb.scts.bean;

public class Branch_officeVO {
	private int		bhf_code;
	private String	bnf_nm;
	private String	bnf_adres;
	private String	bnf_telno;
	
	public int getBhf_code() {
		return bhf_code;
	}
	public void setBhf_code(int bhf_code) {
		this.bhf_code = bhf_code;
	}
	public String getBnf_nm() {
		return bnf_nm;
	}
	public void setBnf_nm(String bnf_nm) {
		this.bnf_nm = bnf_nm;
	}
	public String getBnf_adres() {
		return bnf_adres;
	}
	public void setBnf_adres(String bnf_adres) {
		this.bnf_adres = bnf_adres;
	}
	public String getBnf_telno() {
		return bnf_telno;
	}
	public void setBnf_telno(String bnf_telno) {
		this.bnf_telno = bnf_telno;
	}
	
}
