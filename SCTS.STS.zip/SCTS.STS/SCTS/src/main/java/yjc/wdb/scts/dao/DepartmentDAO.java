package yjc.wdb.scts.dao;

public interface DepartmentDAO {

}
