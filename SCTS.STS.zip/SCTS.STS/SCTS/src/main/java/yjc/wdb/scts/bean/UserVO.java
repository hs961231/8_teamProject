package yjc.wdb.scts.bean;

public class UserVO {
	private String	user_id;
	private String	user_password;
	private String	user_adres;
	private String	user_nm;
	private int		user_brthdy;
	private String	user_mbtlnum;
	private String	user_email;
	private String	user_sexdstn;
	private String	user_mrrg_at;
	private String 	token;
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_adres() {
		return user_adres;
	}
	public void setUser_adres(String user_adres) {
		this.user_adres = user_adres;
	}
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	public int getUser_brthdy() {
		return user_brthdy;
	}
	public void setUser_brthdy(int user_brthdy) {
		this.user_brthdy = user_brthdy;
	}
	public String getUser_mbtlnum() {
		return user_mbtlnum;
	}
	public void setUser_mbtlnum(String user_mbtlnum) {
		this.user_mbtlnum = user_mbtlnum;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_sexdstn() {
		return user_sexdstn;
	}
	public void setUser_sexdstn(String user_sexdstn) {
		this.user_sexdstn = user_sexdstn;
	}
	public String getUser_mrrg_at() {
		return user_mrrg_at;
	}
	public void setUser_mrrg_at(String user_mrrg_at) {
		this.user_mrrg_at = user_mrrg_at;
	}
	
}
