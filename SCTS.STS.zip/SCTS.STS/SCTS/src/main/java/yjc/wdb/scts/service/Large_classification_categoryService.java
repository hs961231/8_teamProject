package yjc.wdb.scts.service;

public interface Large_classification_categoryService {

}
