package yjc.wdb.scts.bean;

public class Purchase_goodsVO {
	private int		bill_code;
	private int		goods_code;
	private int		coupon_code;
	private int		purchsgoods_qy;
	
	public int getBill_code() {
		return bill_code;
	}
	public void setBill_code(int bill_code) {
		this.bill_code = bill_code;
	}
	public int getGoods_code() {
		return goods_code;
	}
	public void setGoods_code(int goods_code) {
		this.goods_code = goods_code;
	}
	public int getCoupon_code() {
		return coupon_code;
	}
	public void setCoupon_code(int coupon_code) {
		this.coupon_code = coupon_code;
	}
	public int getPurchsgoods_qy() {
		return purchsgoods_qy;
	}
	public void setPurchsgoods_qy(int purchsgoods_qy) {
		this.purchsgoods_qy = purchsgoods_qy;
	}
	
}
