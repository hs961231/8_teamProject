package yjc.wdb.scts.bean;

public class BBS_CategoryVO {
	
	private int bbsctgry_code;
	private String bbsctgry_nm;
	public int getBbsctgry_code() {
		return bbsctgry_code;
	}
	public void setBbsctgry_code(int bbsctgry_code) {
		this.bbsctgry_code = bbsctgry_code;
	}
	public String getBbsctgry_nm() {
		return bbsctgry_nm;
	}
	public void setBbsctgry_nm(String bbsctgry_nm) {
		this.bbsctgry_nm = bbsctgry_nm;
	}

}
